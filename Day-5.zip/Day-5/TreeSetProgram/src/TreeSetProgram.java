import java.util.TreeSet;

public class TreeSetProgram {
	
public static void main(String[] args) {
	
	TreeSet<String> EmpName=new TreeSet<String>();
	EmpName.add("Karhik");
	EmpName.add("Gani");
	EmpName.add("Bass");
	EmpName.add("Yasar");
	EmpName.add("Gowtham");
	
	for (String integer : EmpName) {
		System.out.println(integer);
	}
	

	TreeSet<String>Domain=new TreeSet<String>();
	Domain.add("Web Designing");
	Domain.add("Backend Developer");
	Domain.add("Cloud Hosting");
	Domain.add("Page Ranking");
	Domain.add("Testing");
	
	
	System.out.println(Domain);
	
	TreeSet<Object>Company=new TreeSet<Object>();
	Company.addAll(EmpName);
	Company.addAll(Domain);
	System.out.println(Company);
}
}