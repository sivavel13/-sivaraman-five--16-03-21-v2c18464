
import java.util.Iterator;
import java.util.LinkedHashSet;

public class Hashset {

	public static void main(String[] args) {
		LinkedHashSet<Employee> set=new LinkedHashSet<Employee>();
		
		Employee emp1 = new Employee(01, "karthik", 2, "IT");
		Employee emp2 = new Employee(02, "sumit", 3, "HR");
		Employee emp3 = new Employee(03, "viki", 5, "Finance");
		
		set.add(emp1);
		set.add(emp2);
		set.add(emp3);	
		/*Iterator<Employee> i=set.iterator();
		while(i.hasNext())
		{
			System.out.println(i.next());
		}*/
		for(Employee s:set)
		{
			System.out.println("Emp Id:"+s.id+" "+"Emp Name:"+s.Name+" "+"Department:"+s.Experience+" "+"Emp Department:"+s.Department);
		}

	}

}

class Employee{
	int id, Experience;
	String Name,Department;
	public Employee(int id, String name, int exp, String department) {
		super();
		this.id = id;
		Name = name;
		Experience = exp;
		Department = department;
	}	
}



