import java.util.*;
public class Iterator {

	public static void main(String[] args) {
		
		ArrayList<String> brands = new ArrayList<String>();
		brands.add("Addidas");
		brands.add("Nike");
		brands.add("Reebok");
		brands.add("Puma");
		brands.add("Brooks");
	}

}
